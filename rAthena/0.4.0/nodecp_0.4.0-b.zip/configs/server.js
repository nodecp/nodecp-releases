module.exports = {
  mysql: {
    port: 3306,
    user: 'ragnarok',
    password: 'ragnarok',
    host: 'localhost',
    database: 'ragnarok'
  }
};
