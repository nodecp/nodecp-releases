const { readFileSync, statSync } = require('fs');
const pug = require('pug');

module.exports = function(app, dir, method, parent, action, module_cache) {
  if (statSync(`${dir}/${action}`).isDirectory()) {
    console.warn(`\x1b[33mWarning: \x1b[0mFound a directory inside /${parent} ignoring.`)
  } else {
    if (action.endsWith('.pug')) {
      module_cache.set(`/${parent}/${action.split('.')[0]}`, { dir: `${dir}/${action}`, data: readFileSync(`${dir}/${action}`), theme: null });

      app[method](`/${parent}/${action.split('.')[0]}`, async function(req, res) {

        res.render('index', { pugModule: pug, req });
      });
    };
  };
};
