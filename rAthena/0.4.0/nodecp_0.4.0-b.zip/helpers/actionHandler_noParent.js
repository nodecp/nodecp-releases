const { readFileSync } = require('fs');
const pug = require('pug');
const Mysql = require('./mysql');
const SERVER_CONFIG = require('../configs/server');

module.exports = function(app, basedir, module_cache, method, action) {
  let route = action.split('.')[0];

  if (route.toLowerCase() === 'home')
    route = '';

  module_cache.set(`/${route}`, { dir: `${basedir}/modules/${method}/${action}`, data: readFileSync(`${basedir}/modules/${method}/${action}`), theme: null });

  app[method](`/${route}`, async function(req, res) {

    res.render('index', { pugModule: pug, req });
  })
};
