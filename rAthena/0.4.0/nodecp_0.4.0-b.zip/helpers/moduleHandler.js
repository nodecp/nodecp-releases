const { readdirSync, readFileSync, statSync } = require('fs');
const actionHandler = require('./actionHandler');
const actionHandler_noParent = require('./actionHandler_noParent');
const pug = require('pug');
const Mysql = require('./mysql');
const SERVER_CONFIG = require('../configs/server');

module.exports = {
  execFolder: function(app, basedir, folder, module_cache) {
    let supportedMethod = ['post', 'get', 'patch', 'delete', 'all'];

    if (!folder || !supportedMethod.includes(folder.toLowerCase())) {
      console.error(`\x1b[31mError: \x1b[0mUnsupported method given: \x1b[33m${folder}\x1b[0m`)
      process.exit(1);
    };

    folder = folder.toLowerCase();

    console.log(`\x1b[32mLoading: \x1b[0mReading the contents of the /${folder} directory.`)
    let method_dir = readdirSync(`${basedir}/modules/${folder}`);

    if (method_dir.length < 1) {
      console.warn(`\x1b[33mWarning: \x1b[0mNo files or folders found inside /${folder} directory.`)
    } else {
      for (var method of method_dir) {
        console.log(`\x1b[32mFound: \x1b[0m${method} inside /${folder}`)
        let dir = `${basedir}/modules/${folder}/${method}`;

        if (statSync(dir).isDirectory()) {
          let actionParent = readdirSync(dir);

          for (var action of actionParent) {
            actionHandler(app, dir, folder, method, action, module_cache);
          }
        } else {
          if (method.endsWith('.js')) {
            let fileData = require(dir);

            if (!fileData || !fileData.exec || !fileData.route) {
              console.error(`\x1b[31mError: \x1b[0mSome properties are missing from file: ${method} please add them.`)
              process.exit(1);
            }

            app[folder](fileData.route, async function(req, res) {

              fileData.exec(req, res);
            });
          } else if (method.endsWith('pug')) {
            actionHandler_noParent(app, basedir, module_cache, folder, method)
          } else {
            console.warn(`\x1b[33mWarning: \x1b[0mFound invalid file: ${method} ignoring...`);
          }
        };
      }
    };
  }
};
