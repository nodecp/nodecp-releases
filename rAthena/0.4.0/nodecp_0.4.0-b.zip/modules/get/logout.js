module.exports = {
  route: '/account/logout',
  exec: function(req, res) {
    let referrer = req.get('referrer') || '/';

    if (!req.session.loggedin)
      return res.redirect(referrer);
    else {
      req.session.account = null;
      req.session.loggedin = false;

      return res.redirect(referrer);
    }
  }
};
