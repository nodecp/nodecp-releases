const axios = require('axios');
const { createHash } = require('crypto');

module.exports = {
  route: '/login',
  exec: async function(req, res) {
    let referrer = req.get('referrer') || '/';

    if (req.WEB_CONFIG.Recaptcha.enabled) {
      if (!req.body['g-recaptcha-response']) {
        req.flash('error', 'Please complete the recaptcha.');
        return res.redirect(referrer);
      }

      let result = await axios({
        method: 'get',
        url: `https://www.google.com/recaptcha/api/siteverify?secret=${req.WEB_CONFIG.Recaptcha['secret-key']}&response=${req.body['g-recaptcha-response']}&remoteip=${req.connection.remoteAddress}`
      });

      if (!result.data.success) {
        req.flash('error', 'Recaptcha Failed! Please try again.');
        return res.redirect(referrer);
      };
    }

    let account = req.mysql.getNoCache('login', 'userid', req.body.username);

    if (account.length < 1) {
      req.flash('error', `Account ${req.body.username} doesn't exist.`);
      return res.redirect(referrer);
    } else {
      account = account[0];

      if (req.WEB_CONFIG.useMD5)
        req.body.password = createHash('md5').update(account.user_pass).digest('hex');

      if (req.body.password !== account.user_pass) {
        req.flash('error', 'Invalid password given.');
        return res.redirect(referrer);
      };

      if (account.state === 5) {
        req.flash('error', `Sorry but the account ${account.userid} is banned.`)
        return res.redirect(referrer);
      };

      req.session.account = account;
      req.session.loggedin = true;

      return res.redirect('/');
    };
  }
};
