const { createHash } = require('crypto');

module.exports = {
  route: '/register',
  exec: function(req, res) {
    let referrer = req.get('referrer') || '/';

    if (!req.WEB_CONFIG.allowRegister) {
      req.flash('error', 'Sorry but admins has disabled registering on the website.');
      return res.redirect(referrer)
    };

    if (req.WEB_CONFIG.useMD5)
      req.body.password = createHash('md5').update(req.body.password).digest('hex');

    if (req.mysql.has('login', 'userid', req.body.username)) {
      req.flash('error', `Sorry but the account ${req.body.username} already exists. Please choose a different username.`);
      return res.redirect(referrer);
    }

    if (req.WEB_CONFIG.allowDuplicateEmails && req.mysql.get('login', 'email', req.body.email).length > 0) {
      req.flash('error', `Sorry but another account already owns that email. Please use a different one.`);
      return res.redirect(referrer);
    }

    req.mysql.setMultiple('login', [
      {
        column: 'userid',
        value: req.body.username
      },
      {
        column: 'user_pass',
        value: req.body.password
      },
      {
        column: 'sex',
        value: req.body.gender
      },
      {
        column: 'birthdate',
        value: req.moment(`${req.body.birthdate_year}-${req.body.birthdate_month}-${req.body.birthdate_day}`).format('YYYY-MM-DD')
      }
    ]);

    req.flash('success', `Successfully registered <b>${req.body.username}</b>. You may now login <a href="/account/login">here.</a>`);
    return res.redirect(referrer)
  }
};
