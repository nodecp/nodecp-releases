const express = require('express');
const app = express();
const { readdirSync, readFileSync, statSync } = require('fs');
const moduleHandler = require('./helpers/moduleHandler');
const session = require('express-session');
const bodyParser = require('body-parser');
const flash = require('express-flash');
const Mysql = require('./helpers/mysql');
const SERVER_CONFIG = require('./configs/server');

const module_cache = new Map();

app.set('views', `${__dirname}/themes/default/`);
app.set('view engine', 'pug');

app.use(express.static(`${__dirname}/themes/default/`));

app.use(session({
  secret: 'nodecp',
  resave: true,
  saveUninitialized: false
}));

app.use(flash());

app.use(bodyParser.urlencoded({ extended : true }));
app.use(bodyParser.json());

function fetchPage(req, pugModule) {
  return pugModule.render(module_cache.get(req.originalUrl).data.toString(), { pugModule, req });
};

app.use(async function(req, res, next) {
  req.WEB_CONFIG = JSON.parse(readFileSync(`${__dirname}/configs/web.json`));

  if (req.WEB_CONFIG.rss.enabled) {
    let RSS = require('rss-parser');
    let RSS_PARSER = new RSS();

    let feed = await RSS_PARSER.parseURL(req.WEB_CONFIG.rss.link);

    req.RSS_FEED = feed;
  }

  req.moment = require('moment');
  req.mysql = new Mysql(SERVER_CONFIG.mysql)
  req.info = req.flash('info');
  req.error = req.flash('error');
  req.success = req.flash('success');
  req.warn = req.flash('warn');
  req.modules = module_cache;
  req.fetchPage = fetchPage;
  next();
});

let modules = readdirSync(`${__dirname}/modules`);

for (var module of modules) {
  if (statSync(`${__dirname}/modules/${module}`).isDirectory()) {
    moduleHandler.execFolder(app, __dirname, module, module_cache);
  }
}

app.listen(80, function() {
  console.log('\x1b[32mSuccess: \x1b[0mWeb Server is Up!');
});
