module.exports = {
  name: 'Ragnarok',
  mysql: {
    host: 'localhost',
    user: 'ragnarok',
    pass: 'ragnarok',
    database: 'ragnarok',
    port: 3306
  },
  Renewal: true
};
